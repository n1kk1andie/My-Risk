# VMBS Operational Risk & Audit Monitor — Next.js App

Built for VM Building Society. Kemar — read this first.

---

## Project structure

```
/pages
  index.js          → redirects / to /app.html
  /api
    data.js         → GET /api/data  — serves data.xlsx to the browser
    upload.js       → POST /api/upload — receives updated data.xlsx and saves it
/public
  app.html          → the full React app (single HTML file)
  data.xlsx         → live data file (Sandra updates this monthly)
/styles
  app.css           → extracted CSS (reference only — embedded in app.html)
```

---

## How it works

1. User opens the app → redirected to `/app.html`
2. App loads built-in historical data (Jan '24 – May '26) instantly
3. App fetches `/api/data` → reads `data.xlsx` from `/public` → merges any new months
4. Admin (Sandra) opens Settings → uploads updated `data.xlsx`
5. Upload POSTs to `/api/upload` → replaces `/public/data.xlsx` on server
6. All users see new data on next page load

---

## Deploy on Vercel

1. Push this folder to a GitHub repo
2. Connect to Vercel — it auto-detects Next.js
3. Set environment variable in Vercel dashboard:
   - `ADMIN_KEY` = a secure password Sandra will use (replace "vmbs-admin-2024" default)
4. Deploy

**Important:** Update the `x-admin-key` header value in `app.html` to match your `ADMIN_KEY` env var.
Search for `vmbs-admin-2024` in `app.html` and replace with your chosen key.

---

## Changing the admin key

In `app.html` find:
```
headers: { "x-admin-key": "vmbs-admin-2024" },
```
Change `vmbs-admin-2024` to your chosen key. Set the same value as `ADMIN_KEY` in Vercel env vars.

---

## Adding new months (Sandra's workflow)

1. Open Settings tab in app → tap **Download data.xlsx**
2. Open in Excel — add new month column on `er` sheet, new rows on `gov`, `pfl`, `audit` sheets
3. Save file
4. Back in app Settings → tap **Upload updated data.xlsx** → select saved file
5. App previews merged data immediately
6. Upload button also saves to server — all VM Group users see it on next load

---

## Dependencies

- Next.js 14
- formidable (file upload parsing)
- xlsx (Excel parsing — also loaded via CDN in app.html)
- jspdf + jspdf-autotable (PDF export — loaded via CDN in app.html)

Install: `npm install`
Run locally: `npm run dev`
Build: `npm run build`
