// pages/index.js
// Redirects root to the app HTML file served from /public
export async function getServerSideProps() {
  return {
    redirect: {
      destination: '/app.html',
      permanent: false,
    },
  }
}

export default function Home() {
  return null
}
