// pages/api/upload.js
// Receives the updated data.xlsx and replaces the one in /public
import path from 'path'
import fs from 'fs'
import formidable from 'formidable'

export const config = {
  api: {
    bodyParser: false,
  },
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  // Simple admin key check — set ADMIN_KEY in Vercel environment variables
  const adminKey = req.headers['x-admin-key']
  const expectedKey = process.env.ADMIN_KEY || 'vmbs-admin-2024'
  if (adminKey !== expectedKey) {
    return res.status(401).json({ error: 'Unauthorised' })
  }

  const uploadDir = path.join(process.cwd(), 'public')
  const form = formidable({
    uploadDir,
    keepExtensions: true,
    maxFileSize: 10 * 1024 * 1024, // 10MB limit
  })

  try {
    const [, files] = await form.parse(req)
    const file = files.file?.[0]

    if (!file) {
      return res.status(400).json({ error: 'No file received' })
    }

    // Validate it's an xlsx file
    if (!file.originalFilename?.endsWith('.xlsx') && !file.mimetype?.includes('spreadsheet')) {
      fs.unlinkSync(file.filepath)
      return res.status(400).json({ error: 'File must be an .xlsx file' })
    }

    // Replace data.xlsx
    const targetPath = path.join(uploadDir, 'data.xlsx')
    fs.renameSync(file.filepath, targetPath)

    console.log(`data.xlsx updated at ${new Date().toISOString()}`)
    return res.status(200).json({
      success: true,
      message: 'data.xlsx updated successfully',
      timestamp: new Date().toISOString(),
    })
  } catch (err) {
    console.error('Upload error:', err)
    return res.status(500).json({ error: 'Upload failed: ' + err.message })
  }
}
