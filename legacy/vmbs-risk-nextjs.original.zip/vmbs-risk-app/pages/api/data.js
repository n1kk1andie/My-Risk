// pages/api/data.js
// Serves the data.xlsx file to the frontend
import path from 'path'
import fs from 'fs'

export default function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  const filePath = path.join(process.cwd(), 'public', 'data.xlsx')

  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: 'data.xlsx not found' })
  }

  const fileBuffer = fs.readFileSync(filePath)
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
  res.setHeader('Content-Disposition', 'attachment; filename="data.xlsx"')
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate')
  res.send(fileBuffer)
}
