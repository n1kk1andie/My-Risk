/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  api: {
    bodyParser: false, // needed for file upload via formidable
  },
}

module.exports = nextConfig
